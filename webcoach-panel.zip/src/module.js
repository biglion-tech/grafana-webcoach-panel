import {WebcoachAdviceListPanelCtrl} from './webcoach-panel';

export {
  WebcoachAdviceListPanelCtrl as PanelCtrl
};
